import React from "react";
import { View, Text, TextInput, StyleSheet } from "react-native";
import { useColors } from "@/hooks/useColors";

interface InputRowProps {
  label: string;
  unit: string;
  value: string;
  onChangeText: (v: string) => void;
  placeholder?: string;
  hint?: string;
}

export function InputRow({ label, unit, value, onChangeText, placeholder = "0", hint }: InputRowProps) {
  const colors = useColors();

  return (
    <View style={[styles.container, { backgroundColor: colors.card, borderColor: colors.border }]}>
      <View style={styles.row}>
        <View style={[styles.unitBadge, { backgroundColor: colors.muted }]}>
          <Text style={[styles.unit, { color: colors.mutedForeground }]}>{unit}</Text>
        </View>
        <TextInput
          style={[styles.input, { color: colors.foreground }]}
          value={value}
          onChangeText={onChangeText}
          placeholder={placeholder}
          placeholderTextColor={colors.mutedForeground}
          keyboardType="numeric"
          textAlign="right"
          testID={`input-${label}`}
        />
        <Text style={[styles.label, { color: colors.foreground }]} numberOfLines={1}>{label}</Text>
      </View>
      {hint ? <Text style={[styles.hint, { color: colors.mutedForeground }]}>{hint}</Text> : null}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    borderRadius: 12,
    borderWidth: 1,
    padding: 14,
    marginBottom: 10,
  },
  row: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
  },
  label: {
    flex: 1,
    fontSize: 15,
    fontWeight: "600",
    textAlign: "right",
  },
  input: {
    width: 100,
    fontSize: 16,
    fontWeight: "700",
    textAlign: "right",
    paddingVertical: 4,
    paddingHorizontal: 8,
  },
  unitBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
  },
  unit: {
    fontSize: 12,
    fontWeight: "600",
  },
  hint: {
    fontSize: 11,
    textAlign: "right",
    marginTop: 4,
  },
});
