import React, { useEffect, useRef } from "react";
import { View, Text, StyleSheet, Animated } from "react-native";
import { useColors } from "@/hooks/useColors";

interface ResultCardProps {
  totalKVA: number;
  totalKW: number;
  recommendedSize: number;
  hasWarning?: boolean;
}

export function ResultCard({ totalKVA, totalKW, recommendedSize, hasWarning }: ResultCardProps) {
  const colors = useColors();
  const animVal = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.spring(animVal, { toValue: 1, useNativeDriver: true, tension: 80, friction: 8 }).start();
  }, [totalKVA]);

  return (
    <Animated.View
      style={[
        styles.container,
        {
          backgroundColor: colors.card,
          borderColor: hasWarning ? colors.warning : colors.syrianGreen,
          transform: [{ scale: animVal }],
        },
      ]}
    >
      <View style={[styles.header, { backgroundColor: hasWarning ? colors.warning : colors.syrianGreen }]}>
        <Text style={styles.headerText}>نتيجة الحساب</Text>
      </View>
      <View style={styles.body}>
        <ResultRow label="إجمالي KVA" value={`${totalKVA.toFixed(2)} KVA`} color={colors.syrianRed} />
        <ResultRow label="إجمالي KW" value={`${totalKW.toFixed(2)} KW`} color={colors.syrianGreen} />
        <View style={[styles.divider, { backgroundColor: colors.border }]} />
        <View style={[styles.recommendRow, { backgroundColor: colors.muted, borderRadius: 10 }]}>
          <Text style={[styles.recommendValue, { color: colors.syrianRed }]}>{recommendedSize} KVA</Text>
          <Text style={[styles.recommendLabel, { color: colors.foreground }]}>المولد المقترح</Text>
        </View>
        {hasWarning && (
          <Text style={[styles.warning, { color: colors.warning }]}>
            ⚠️ الحمل يتجاوز الأحجام القياسية، يُنصح بمراجعة المختص
          </Text>
        )}
      </View>
    </Animated.View>
  );
}

function ResultRow({ label, value, color }: { label: string; value: string; color: string }) {
  const colors = useColors();
  return (
    <View style={styles.resultRow}>
      <Text style={[styles.resultValue, { color }]}>{value}</Text>
      <Text style={[styles.resultLabel, { color: colors.mutedForeground }]}>{label}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    borderRadius: 16,
    borderWidth: 2,
    overflow: "hidden",
    marginTop: 16,
  },
  header: {
    paddingVertical: 12,
    alignItems: "center",
  },
  headerText: {
    color: "#FFFFFF",
    fontSize: 16,
    fontWeight: "700",
  },
  body: {
    padding: 16,
    gap: 10,
  },
  resultRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  resultLabel: {
    fontSize: 14,
    fontWeight: "500",
  },
  resultValue: {
    fontSize: 20,
    fontWeight: "800",
  },
  divider: {
    height: 1,
    marginVertical: 4,
  },
  recommendRow: {
    padding: 14,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  recommendLabel: {
    fontSize: 14,
    fontWeight: "600",
  },
  recommendValue: {
    fontSize: 28,
    fontWeight: "900",
  },
  warning: {
    fontSize: 12,
    textAlign: "right",
    marginTop: 6,
    fontWeight: "600",
  },
});
