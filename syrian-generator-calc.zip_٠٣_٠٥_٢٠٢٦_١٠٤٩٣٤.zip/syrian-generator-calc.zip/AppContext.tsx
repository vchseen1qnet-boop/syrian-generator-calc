import React, { createContext, useContext, useState, useEffect, ReactNode } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";

export interface LoadEntry {
  id: string;
  name: string;
  motors: number;
  airConditioners: number;
  lights: number;
  heaters: number;
  otherLoads: number;
  powerFactor: number;
  safetyMargin: boolean;
  totalKVA: number;
  totalKW: number;
  recommendedSize: number;
  date: string;
}

export interface AppSettings {
  dieselPrice: number;
  dieselPriceUSD: number;
  darkMode: boolean;
  companyName: string;
  companyPhone: string;
}

const DEFAULT_SETTINGS: AppSettings = {
  dieselPrice: 9500,
  dieselPriceUSD: 0.75,
  darkMode: false,
  companyName: "حاسبة المولدات السورية",
  companyPhone: "+963932365420",
};

interface AppContextType {
  history: LoadEntry[];
  addToHistory: (entry: LoadEntry) => void;
  clearHistory: () => void;
  settings: AppSettings;
  updateSettings: (s: Partial<AppSettings>) => void;
  dieselPrice: number;
  setDieselPrice: (price: number) => void;
  dieselPriceUSD: number;
  setDieselPriceUSD: (price: number) => void;
}

const AppContext = createContext<AppContextType | null>(null);

export function AppProvider({ children }: { children: ReactNode }) {
  const [history, setHistory] = useState<LoadEntry[]>([]);
  const [settings, setSettings] = useState<AppSettings>(DEFAULT_SETTINGS);
  const [dieselPrice, setDieselPriceState] = useState(DEFAULT_SETTINGS.dieselPrice);
  const [dieselPriceUSD, setDieselPriceUSDState] = useState(DEFAULT_SETTINGS.dieselPriceUSD);

  useEffect(() => {
    loadData();
  }, []);

  async function loadData() {
    try {
      const [historyRaw, settingsRaw] = await Promise.all([
        AsyncStorage.getItem("calculation_history"),
        AsyncStorage.getItem("app_settings"),
      ]);
      if (historyRaw) setHistory(JSON.parse(historyRaw));
      if (settingsRaw) {
        const s = JSON.parse(settingsRaw) as AppSettings;
        const merged = { ...DEFAULT_SETTINGS, ...s };
        setSettings(merged);
        setDieselPriceState(merged.dieselPrice);
        setDieselPriceUSDState(merged.dieselPriceUSD ?? DEFAULT_SETTINGS.dieselPriceUSD);
      }
    } catch (_) {}
  }

  async function addToHistory(entry: LoadEntry) {
    const next = [entry, ...history].slice(0, 50);
    setHistory(next);
    await AsyncStorage.setItem("calculation_history", JSON.stringify(next));
  }

  async function clearHistory() {
    setHistory([]);
    await AsyncStorage.removeItem("calculation_history");
  }

  async function updateSettings(patch: Partial<AppSettings>) {
    const next = { ...settings, ...patch };
    setSettings(next);
    if (patch.dieselPrice !== undefined) setDieselPriceState(patch.dieselPrice);
    if (patch.dieselPriceUSD !== undefined) setDieselPriceUSDState(patch.dieselPriceUSD);
    await AsyncStorage.setItem("app_settings", JSON.stringify(next));
  }

  function setDieselPrice(price: number) {
    updateSettings({ dieselPrice: price });
  }

  function setDieselPriceUSD(price: number) {
    updateSettings({ dieselPriceUSD: price });
  }

  return (
    <AppContext.Provider
      value={{
        history, addToHistory, clearHistory,
        settings, updateSettings,
        dieselPrice, setDieselPrice,
        dieselPriceUSD, setDieselPriceUSD,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error("useApp must be used within AppProvider");
  return ctx;
}
