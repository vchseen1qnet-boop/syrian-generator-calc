import { ScrollViewStyleReset } from "expo-router/html";
import type { PropsWithChildren } from "react";

export default function Root({ children }: PropsWithChildren) {
  return (
    <html lang="ar" dir="rtl">
      <head>
        <meta charSet="utf-8" />
        <meta httpEquiv="X-UA-Compatible" content="IE=edge" />
        <meta
          name="viewport"
          content="width=device-width, initial-scale=1, shrink-to-fit=no"
        />

        {/* PWA manifest */}
        <link rel="manifest" href="/manifest.json" />

        {/* Theme & brand colors */}
        <meta name="theme-color" content="#007A3D" />
        <meta name="msapplication-TileColor" content="#007A3D" />
        <meta name="application-name" content="حاسبة مولدات" />

        {/* iOS PWA */}
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
        <meta name="apple-mobile-web-app-title" content="حاسبة مولدات" />
        <link rel="apple-touch-icon" href="/assets/images/icon.png" />

        {/* Android Chrome */}
        <meta name="mobile-web-app-capable" content="yes" />

        {/* SEO */}
        <meta
          name="description"
          content="حاسبة أحمال المولدات الكهربائية، التكاليف اليومية، واستهلاك الديزل للسوق السوري"
        />

        <ScrollViewStyleReset />
      </head>
      <body>{children}</body>
    </html>
  );
}
