export const GENERATOR_SIZES = [5, 8, 10, 12, 15, 20, 25, 30, 40, 50, 60, 75, 100, 125, 150, 200];

export function findRecommendedSize(kva: number): number {
  for (const size of GENERATOR_SIZES) {
    if (size >= kva) return size;
  }
  return Math.ceil(kva / 25) * 25;
}

export interface LoadInputs {
  motors: number;
  airConditioners: number;
  lights: number;
  heaters: number;
  otherLoads: number;
  powerFactor: number;
  safetyMargin: boolean;
}

export interface LoadResult {
  motorKVA: number;
  acKVA: number;
  lightsKVA: number;
  heatersKVA: number;
  otherKVA: number;
  subtotalKVA: number;
  totalKVA: number;
  totalKW: number;
  recommendedSize: number;
}

export function calculateLoads(inputs: LoadInputs): LoadResult {
  const { motors, airConditioners, lights, heaters, otherLoads, powerFactor, safetyMargin } = inputs;
  const pf = powerFactor > 0 ? powerFactor : 0.8;

  const motorKVA = motors / pf;
  const acKVA = airConditioners * 3.5;
  const lightsKVA = lights / 1000 / pf;
  const heatersKVA = heaters / 1000 / pf;
  const otherKVA = otherLoads / 1000 / pf;

  const subtotalKVA = motorKVA + acKVA + lightsKVA + heatersKVA + otherKVA;
  const totalKVA = safetyMargin ? subtotalKVA * 1.2 : subtotalKVA;
  const totalKW = totalKVA * pf;

  return {
    motorKVA,
    acKVA,
    lightsKVA,
    heatersKVA,
    otherKVA,
    subtotalKVA,
    totalKVA,
    totalKW,
    recommendedSize: findRecommendedSize(totalKVA),
  };
}

export interface DieselConsumption {
  litersPerHour: number;
  litersPerDay: number;
  litersPerMonth: number;
  costPerDay: number;
  costPerMonth: number;
  costPerYear: number;
}

export function calculateDieselCost(
  kva: number,
  hoursPerDay: number,
  dieselPricePerLiter: number,
  efficiencyLPerKVAPerHour: number
): DieselConsumption {
  const litersPerHour = kva * efficiencyLPerKVAPerHour;
  const litersPerDay = litersPerHour * hoursPerDay;
  const litersPerMonth = litersPerDay * 30;
  const costPerDay = litersPerDay * dieselPricePerLiter;
  const costPerMonth = costPerDay * 30;
  const costPerYear = costPerMonth * 12;

  return { litersPerHour, litersPerDay, litersPerMonth, costPerDay, costPerMonth, costPerYear };
}

export function getDefaultEfficiency(kva: number): number {
  if (kva <= 5) return 0.30;
  if (kva <= 10) return 0.25;
  if (kva <= 15) return 0.23;
  if (kva <= 20) return 0.225;
  if (kva <= 30) return 0.217;
  if (kva <= 50) return 0.20;
  return 0.20;
}

export const REFERENCE_TABLE = [
  { kva: 5, litersPerHour: 1.5 },
  { kva: 10, litersPerHour: 2.5 },
  { kva: 15, litersPerHour: 3.5 },
  { kva: 20, litersPerHour: 4.5 },
  { kva: 30, litersPerHour: 6.5 },
  { kva: 50, litersPerHour: 10.0 },
  { kva: 60, litersPerHour: 12.0 },
  { kva: 75, litersPerHour: 15.0 },
  { kva: 100, litersPerHour: 20.0 },
  { kva: 125, litersPerHour: 24.0 },
  { kva: 150, litersPerHour: 28.0 },
];

export function formatNumber(n: number, decimals = 1): string {
  return n.toFixed(decimals);
}

export function formatCurrency(n: number): string {
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(2)} مليون ل.س`;
  if (n >= 1_000) return `${(n / 1_000).toFixed(1)} ألف ل.س`;
  return `${n.toFixed(0)} ل.س`;
}
