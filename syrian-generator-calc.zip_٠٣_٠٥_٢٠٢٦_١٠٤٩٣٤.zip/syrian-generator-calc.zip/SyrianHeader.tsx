import React from "react";
import { View, Text, StyleSheet, Platform } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useColors } from "@/hooks/useColors";

interface SyrianHeaderProps {
  title: string;
  subtitle?: string;
}

export function SyrianHeader({ title, subtitle }: SyrianHeaderProps) {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const topPad = Platform.OS === "web" ? 67 : insets.top;

  return (
    <View style={[styles.container, { paddingTop: topPad + 12, backgroundColor: colors.headerBg }]}>
      <View style={styles.flagStripe}>
        <View style={[styles.stripe, { backgroundColor: colors.syrianGreen }]} />
        <View style={[styles.stripe, { backgroundColor: colors.syrianWhite }]} />
        <View style={[styles.stripe, { backgroundColor: colors.syrianBlack }]} />
      </View>
      <View style={styles.textContainer}>
        <Text style={[styles.title, { color: "#FFFFFF" }]}>{title}</Text>
        {subtitle ? <Text style={[styles.subtitle, { color: "#CCCCCC" }]}>{subtitle}</Text> : null}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    paddingBottom: 16,
    paddingHorizontal: 20,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 6,
  },
  flagStripe: {
    flexDirection: "row",
    height: 4,
    borderRadius: 2,
    overflow: "hidden",
    marginBottom: 12,
  },
  stripe: {
    flex: 1,
  },
  textContainer: {
    alignItems: "flex-end",
  },
  title: {
    fontSize: 22,
    fontWeight: "700",
    textAlign: "right",
  },
  subtitle: {
    fontSize: 13,
    marginTop: 2,
    textAlign: "right",
  },
});
