import React from "react";
import { TouchableOpacity, StyleSheet, Linking, Platform, View, Text } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import * as Haptics from "expo-haptics";

interface WhatsAppButtonProps {
  totalKVA?: number;
  recommendedSize?: number;
  litersPerHour?: number;
}

export function WhatsAppButton({ totalKVA, recommendedSize, litersPerHour }: WhatsAppButtonProps) {
  const insets = useSafeAreaInsets();
  const bottomPad = Platform.OS === "web" ? 34 : insets.bottom;

  async function handlePress() {
    await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    const phone = "+963932365420";
    let message = "مرحباً، قمت بحساب احتياجي للمولد:\n";
    if (totalKVA) message += `- إجمالي الأحمال: ${totalKVA.toFixed(1)} KVA\n`;
    if (recommendedSize) message += `- المولد المقترح: ${recommendedSize} KVA\n`;
    if (litersPerHour) message += `- استهلاك الديزل المتوقع: ${litersPerHour.toFixed(1)} ليتر/ساعة\n`;
    message += "أرغب بالاستفسار عن توفر المولد والسعر.";

    const url = `whatsapp://send?phone=${phone}&text=${encodeURIComponent(message)}`;
    const fallback = `https://wa.me/${phone.replace("+", "")}?text=${encodeURIComponent(message)}`;

    const canOpen = await Linking.canOpenURL(url);
    Linking.openURL(canOpen ? url : fallback).catch(() => {});
  }

  return (
    <TouchableOpacity
      style={[styles.button, { bottom: bottomPad + 90 }]}
      onPress={handlePress}
      activeOpacity={0.85}
      testID="whatsapp-button"
    >
      <Ionicons name="logo-whatsapp" size={28} color="#FFFFFF" />
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  button: {
    position: "absolute",
    right: 20,
    width: 58,
    height: 58,
    borderRadius: 29,
    backgroundColor: "#25D366",
    alignItems: "center",
    justifyContent: "center",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.35,
    shadowRadius: 6,
    elevation: 10,
    zIndex: 999,
  },
});
