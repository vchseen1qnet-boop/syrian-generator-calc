const colors = {
  light: {
    text: "#1a1a1a",
    tint: "#CE1126",

    background: "#F5F5F5",
    foreground: "#1a1a1a",

    card: "#FFFFFF",
    cardForeground: "#1a1a1a",

    primary: "#CE1126",
    primaryForeground: "#FFFFFF",

    secondary: "#007A3D",
    secondaryForeground: "#FFFFFF",

    muted: "#E8E8E8",
    mutedForeground: "#666666",

    accent: "#007A3D",
    accentForeground: "#FFFFFF",

    destructive: "#CE1126",
    destructiveForeground: "#FFFFFF",

    border: "#DEDEDE",
    input: "#FFFFFF",

    // Syrian flag colors
    syrianRed: "#CE1126",
    syrianGreen: "#007A3D",
    syrianBlack: "#000000",
    syrianWhite: "#FFFFFF",

    // UI extras
    warning: "#F59E0B",
    success: "#007A3D",
    info: "#2563EB",
    surface: "#FFFFFF",
    headerBg: "#1a1a1a",
    tabBar: "#1a1a1a",
    tabBarActive: "#CE1126",
    tabBarInactive: "#888888",
  },
  dark: {
    text: "#F5F5F5",
    tint: "#FF3344",

    background: "#0F0F0F",
    foreground: "#F5F5F5",

    card: "#1E1E1E",
    cardForeground: "#F5F5F5",

    primary: "#CE1126",
    primaryForeground: "#FFFFFF",

    secondary: "#007A3D",
    secondaryForeground: "#FFFFFF",

    muted: "#2A2A2A",
    mutedForeground: "#999999",

    accent: "#007A3D",
    accentForeground: "#FFFFFF",

    destructive: "#FF3344",
    destructiveForeground: "#FFFFFF",

    border: "#333333",
    input: "#1E1E1E",

    syrianRed: "#CE1126",
    syrianGreen: "#007A3D",
    syrianBlack: "#000000",
    syrianWhite: "#FFFFFF",

    warning: "#F59E0B",
    success: "#22C55E",
    info: "#3B82F6",
    surface: "#1E1E1E",
    headerBg: "#0F0F0F",
    tabBar: "#0F0F0F",
    tabBarActive: "#CE1126",
    tabBarInactive: "#555555",
  },
  radius: 12,
};

export default colors;
